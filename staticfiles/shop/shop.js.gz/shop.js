$(document).ready(function(){
  $('.drop_btn').click(function(){
    $('.drop_list').toggleClass('show');
    $('#products_container').toggleClass('slided');
  });
});
